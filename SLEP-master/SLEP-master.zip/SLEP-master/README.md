# SLEP
Sparse Learning via Efficient Projection (mirror copy of latest version in http://www.yelab.net/software/SLEP/)
